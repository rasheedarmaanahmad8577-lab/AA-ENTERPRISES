"use strict";

/* =========================================================
   AA ENTERPRISES — PREMIUM WEBSITE JS
========================================================= */


/* =========================================================
   1. WHATSAPP
========================================================= */

const WHATSAPP_NUMBER = "917007126281";

const DEFAULT_MESSAGE =
  "Hello AA Enterprises, I would like to discuss an interior/exterior project.";

document.querySelectorAll(".whatsapp").forEach((button) => {

  button.addEventListener("click", function (event) {

    event.preventDefault();

    const message =
      this.dataset.wa || DEFAULT_MESSAGE;

    const whatsappURL =
      "https://wa.me/" +
      WHATSAPP_NUMBER +
      "?text=" +
      encodeURIComponent(message);

    window.open(
      whatsappURL,
      "_blank",
      "noopener,noreferrer"
    );

  });

});


/* =========================================================
   2. MOBILE MENU
========================================================= */

const menuButton =
  document.getElementById("menu");

const mobileMenu =
  document.getElementById("mobileMenu");


if (menuButton && mobileMenu) {

  menuButton.addEventListener("click", () => {

    mobileMenu.classList.toggle("open");

  });


  mobileMenu
    .querySelectorAll("a")
    .forEach((link) => {

      link.addEventListener("click", () => {

        mobileMenu.classList.remove("open");

      });

    });

}


/* =========================================================
   3. SCROLL PROGRESS
========================================================= */

const progress =
  document.getElementById("progress");


function updateProgress() {

  if (!progress) return;

  const documentHeight =
    document.documentElement.scrollHeight -
    window.innerHeight;

  if (documentHeight <= 0) {

    progress.style.width = "0%";
    return;

  }

  const percentage =
    (window.scrollY / documentHeight) * 100;

  progress.style.width =
    Math.min(percentage, 100) + "%";

}


window.addEventListener(
  "scroll",
  updateProgress,
  { passive: true }
);

updateProgress();


/* =========================================================
   5. SMOOTH ANCHOR SCROLL
========================================================= */

document
  .querySelectorAll('a[href^="#"]')
  .forEach((link) => {

    link.addEventListener("click", function (event) {

      const targetID =
        this.getAttribute("href");

      if (
        !targetID ||
        targetID === "#"
      ) return;


      const target =
        document.querySelector(targetID);

      if (!target) return;


      event.preventDefault();


      target.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });

    });

  });


/* =========================================================
   6. GSAP ANIMATIONS
========================================================= */

if (
  typeof gsap !== "undefined" &&
  typeof ScrollTrigger !== "undefined"
) {

  gsap.registerPlugin(
    ScrollTrigger
  );


  /* -------------------------------------------------------
     LOADER
  ------------------------------------------------------- */

  const loader =
    document.getElementById("loader");


  const loaderTimeline =
    gsap.timeline();


  loaderTimeline

    .to(
      ".loader-line span",
      {
        width: "100%",
        duration: 1.2,
        ease: "power2.inOut"
      }
    )

    .to(
      ".loader",
      {
        yPercent: -100,
        duration: 1,
        delay: 0.15,
        ease: "power4.inOut"
      }
    )

    .from(
      ".hero-copy .reveal",
      {
        opacity: 0,
        y: 40,
        stagger: 0.1,
        duration: 1,
        ease: "power3.out"
      },
      "-=0.45"
    )

    .from(
      ".hero-image-wrap",
      {
        opacity: 0,
        scale: 0.9,
        rotation: 0,
        duration: 1.2,
        ease: "power3.out"
      },
      "-=0.9"
    )

    .add(() => {

      if (loader) {

        loader.style.pointerEvents =
          "none";

      }

    });


  /* -------------------------------------------------------
     GENERAL REVEAL ANIMATIONS
  ------------------------------------------------------- */

  const revealElements =
    gsap.utils.toArray(
      ".reveal"
    );


  revealElements.forEach((element) => {

    if (
      element.closest(".hero")
    ) return;


    gsap.to(
      element,
      {
        opacity: 1,
        y: 0,
        duration: 1,
        ease: "power3.out",

        scrollTrigger: {

          trigger: element,

          start: "top 86%",

          once: true

        }

      }
    );

  });


  /* -------------------------------------------------------
     HERO IMAGE PARALLAX
  ------------------------------------------------------- */

  const heroImage =
    document.querySelector(
      ".hero-image"
    );


  if (heroImage) {

    gsap.to(
      heroImage,
      {

        yPercent: 10,

        scale: 1.08,

        ease: "none",

        scrollTrigger: {

          trigger: ".hero",

          start: "top top",

          end: "bottom top",

          scrub: 1

        }

      }
    );

  }


  /* -------------------------------------------------------
     HERO TEXT PARALLAX
  ------------------------------------------------------- */

  const heroCopy =
    document.querySelector(
      ".hero-copy"
    );


  if (heroCopy) {

    gsap.to(
      heroCopy,
      {

        yPercent: -12,

        ease: "none",

        scrollTrigger: {

          trigger: ".hero",

          start: "top top",

          end: "bottom top",

          scrub: 1

        }

      }
    );

  }


  /* -------------------------------------------------------
     FEATURE IMAGE ZOOM
  ------------------------------------------------------- */

  const featureImage =
    document.querySelector(
      ".feature-image img"
    );


  if (featureImage) {

    gsap.fromTo(
      featureImage,

      {
        scale: 1.12
      },

      {
        scale: 1,

        ease: "none",

        scrollTrigger: {

          trigger: ".feature-image",

          start: "top bottom",

          end: "bottom top",

          scrub: 1

        }

      }

    );

  }


  /* -------------------------------------------------------
     PROJECT CARD REVEAL
  ------------------------------------------------------- */

  const projectCards =
    gsap.utils.toArray(
      ".project-card"
    );


  projectCards.forEach(
    (card, index) => {

      gsap.from(
        card,
        {

          opacity: 0,

          y: 50,

          duration: 0.9,

          delay:
            (index % 3) * 0.08,

          ease: "power3.out",

          scrollTrigger: {

            trigger: card,

            start: "top 90%",

            once: true

          }

        }
      );

    }
  );


  /* -------------------------------------------------------
     SERVICE HOVER ANIMATION
  ------------------------------------------------------- */

  document
    .querySelectorAll(".service")
    .forEach((service) => {

      const arrow =
        service.querySelector("b");


      if (!arrow) return;


      service.addEventListener(
        "mouseenter",
        () => {

          gsap.to(
            arrow,
            {
              x: 8,
              y: -8,
              duration: 0.3,
              ease: "power2.out"
            }
          );

        }
      );


      service.addEventListener(
        "mouseleave",
        () => {

          gsap.to(
            arrow,
            {
              x: 0,
              y: 0,
              duration: 0.3,
              ease: "power2.out"
            }
          );

        }
      );

    });

}


/* =========================================================
   7. THREE.JS 3D HERO
========================================================= */

const hero3D =
  document.getElementById("hero3d");


if (
  hero3D &&
  typeof THREE !== "undefined"
) {

  const scene =
    new THREE.Scene();


  const camera =
    new THREE.PerspectiveCamera(
      42,
      hero3D.clientWidth /
      hero3D.clientHeight,
      0.1,
      100
    );


  camera.position.set(
    0,
    0,
    8
  );


  const renderer =
    new THREE.WebGLRenderer({
      alpha: true,
      antialias: true
    });


  renderer.setPixelRatio(
    Math.min(
      window.devicePixelRatio,
      1.8
    )
  );


  renderer.setSize(
    hero3D.clientWidth,
    hero3D.clientHeight
  );


  renderer.outputEncoding =
    THREE.sRGBEncoding;


  hero3D.appendChild(
    renderer.domElement
  );


  /* -------------------------------------------------------
     MAIN 3D GROUP
  ------------------------------------------------------- */

  const group =
    new THREE.Group();


  scene.add(group);


  /* -------------------------------------------------------
     MATERIALS
  ------------------------------------------------------- */

  const orangeMaterial =
    new THREE.MeshStandardMaterial({

      color: 0xff9d00,

      metalness: 0.85,

      roughness: 0.2

    });


  const darkMaterial =
    new THREE.MeshStandardMaterial({

      color: 0x17130d,

      metalness: 0.9,

      roughness: 0.16

    });


  /* -------------------------------------------------------
     3D RINGS
  ------------------------------------------------------- */

  const ringSizes = [
    1.65,
    2.15,
    2.7
  ];


  ringSizes.forEach(
    (radius, index) => {

      const geometry =
        new THREE.TorusGeometry(
          radius,
          0.035,
          16,
          140
        );


      const ring =
        new THREE.Mesh(
          geometry,
          index === 1
            ? darkMaterial
            : orangeMaterial
        );


      ring.rotation.x =
        index * 0.32;


      ring.rotation.y =
        index * 0.55;


      group.add(ring);

    }
  );


  /* -------------------------------------------------------
     3D CENTER CORE
  ------------------------------------------------------- */

  const coreGeometry =
    new THREE.IcosahedronGeometry(
      1.05,
      3
    );


  const core =
    new THREE.Mesh(
      coreGeometry,
      darkMaterial
    );


  group.add(core);


  /* -------------------------------------------------------
     PARTICLES
  ------------------------------------------------------- */

  const particleCount =
    700;


  const particlePositions =
    new Float32Array(
      particleCount * 3
    );


  for (
    let i = 0;
    i < particleCount;
    i++
  ) {

    const angle =
      Math.random() *
      Math.PI *
      2;


    const radius =
      3 +
      Math.random() * 3.5;


    particlePositions[
      i * 3
    ] =
      Math.cos(angle) *
      radius;


    particlePositions[
      i * 3 + 1
    ] =
      (Math.random() - 0.5) * 5;


    particlePositions[
      i * 3 + 2
    ] =
      Math.sin(angle) *
      radius;

  }


  const particleGeometry =
    new THREE.BufferGeometry();


  particleGeometry.setAttribute(
    "position",
    new THREE.BufferAttribute(
      particlePositions,
      3
    )
  );


  const particleMaterial =
    new THREE.PointsMaterial({

      color: 0xffb52e,

      size: 0.018,

      transparent: true,

      opacity: 0.7

    });


  const particles =
    new THREE.Points(
      particleGeometry,
      particleMaterial
    );


  scene.add(particles);


  /* -------------------------------------------------------
     LIGHTS
  ------------------------------------------------------- */

  const ambientLight =
    new THREE.AmbientLight(
      0xffffff,
      0.55
    );


  scene.add(
    ambientLight
  );


  const pointLight =
    new THREE.PointLight(
      0xff9d00,
      2.4,
      18
    );


  pointLight.position.set(
    2,
    2,
    5
  );


  scene.add(
    pointLight
  );


  /* -------------------------------------------------------
     MOUSE MOVEMENT
  ------------------------------------------------------- */

  let targetX = 0;
  let targetY = 0;


  window.addEventListener(
    "mousemove",
    (event) => {

      targetX =
        (
          event.clientX /
          window.innerWidth -
          0.5
        ) * 0.8;


      targetY =
        (
          event.clientY /
          window.innerHeight -
          0.5
        ) * 0.5;

    }
  );


  /* -------------------------------------------------------
     SCROLL
  ------------------------------------------------------- */

  let scrollAmount = 0;


  window.addEventListener(
    "scroll",
    () => {

      scrollAmount =
        window.scrollY;

    },
    {
      passive: true
    }
  );


  /* -------------------------------------------------------
     ANIMATION LOOP
  ------------------------------------------------------- */

  const clock =
    new THREE.Clock();


  function animate3D() {

    requestAnimationFrame(
      animate3D
    );


    const time =
      clock.getElapsedTime();


    group.rotation.y +=
      0.0025;


    group.rotation.x +=
      (
        targetY -
        group.rotation.x
      ) * 0.008;


    group.position.x +=
      (
        targetX -
        group.position.x
      ) * 0.012;


    group.position.y =
      Math.sin(
        time * 0.45
      ) * 0.12 -
      Math.min(
        scrollAmount / 1200,
        0.8
      );


    particles.rotation.y -=
      0.0008;


    renderer.render(
      scene,
      camera
    );

  }


  animate3D();


  /* -------------------------------------------------------
     RESPONSIVE THREE.JS
  ------------------------------------------------------- */

  function resize3D() {

    if (!hero3D) return;


    const width =
      hero3D.clientWidth;


    const height =
      hero3D.clientHeight;


    if (
      width <= 0 ||
      height <= 0
    ) return;


    camera.aspect =
      width / height;


    camera.updateProjectionMatrix();


    renderer.setSize(
      width,
      height
    );

  }


  window.addEventListener(
    "resize",
    resize3D
  );


  resize3D();

}


/* =========================================================
   8. REDUCED MOTION SUPPORT
========================================================= */

const reducedMotion =
  window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;


if (reducedMotion) {

  document
    .querySelectorAll(".reveal")
    .forEach((element) => {

      element.style.opacity = "1";
      element.style.transform =
        "none";

    });

}